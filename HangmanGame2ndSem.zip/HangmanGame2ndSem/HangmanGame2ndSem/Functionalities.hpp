//
//  Functionalities.hpp
//  HangmanGame2ndSem
//
//  Created by Deso>k_ii on 3/23/21.
//

#ifndef Functionalities_hpp
#define Functionalities_hpp

#include <stdio.h>

#endif /* Functionalities_hpp */
